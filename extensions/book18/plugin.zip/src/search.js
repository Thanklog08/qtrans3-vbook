load("config.js");

// 21/11 (BBook v3): trang /q/<từ khoá> đổi giao diện, kết quả nằm ở ul.list-group > li.list-group-item (không còn .col-md-6 ul li)
// → bản cũ trả rỗng. Link tương đối /chapters/<tên> → thêm BASE_URL. Trang sau chỉ khi thanh phân trang còn nút "next" chưa tắt.
function execute(key, page) {
    if (!page) page = "1";
    var response = fetch(BASE_URL + "/q/" + encodeURIComponent(key) + "?page=" + page);
    if (!response.ok) return null;
    var doc = response.html();
    var rows = doc.select(".list-group .list-group-item");
    if (rows.size() === 0) rows = doc.select(".col-md-6 ul li");
    var books = [];
    rows.forEach(function (e) {
        var a = e.select("a");
        if (a.size() === 0) return;
        a = a.first();
        var href = (a.attr("href") + "").trim();
        if (!href) return;
        books.push({
            name: (a.text() + "").trim(),
            link: href.indexOf("http") === 0 ? href : BASE_URL + href,
            description: "",
            host: BASE_URL
        });
    });
    var next = doc.select(".pagination .next").size() > 0 && doc.select(".pagination .next.disabled").size() === 0
        ? String(parseInt(page) + 1) : null;
    return Response.success(books, next);
}
