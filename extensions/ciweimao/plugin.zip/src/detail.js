// BBook v3 (17/11/2026): site trả trang theo User-Agent, kể cả link www — UA điện thoại (vBook, B-trans) nhận giao diện wap:
// .book-info h1.book (tên), p.author ("tác giả 著 / thể loại"), .cover img[data-original], p.intro ("… / 连载中"), .book-desc .desc-cnt.
// UA máy tính nhận .book-info h1.title (tên + <span><a>tác giả</a> 著</span>), .book-hd .cover img[src], p.update-state, .book-desc.
// Bản gốc chỉ đọc h3.title (giao diện cũ) → trang wap trả "原创作者" (ô tác giả bên lề) cho mọi truyện, tác giả rỗng, vBook không có nút Đọc.
// Lưu ý runtime vBook: select(...).first() không trả null khi rỗng → kiểm size().
function one(doc, sel) {
    var e = doc.select(sel);
    return e.size() > 0 ? e.first() : null;
}

function txt(e) { return e ? String(e.text()).trim() : ""; }

function execute(url) {
    var doc = Http.get(url.replace('wap.', 'www.')).html();
    var name = "", author = "", cover = "", state = "", desc = "";
    var wap = one(doc, ".book-info h1.book");
    if (wap) {
        name = txt(wap);
        author = txt(one(doc, ".book-info p.author")).split(/\s*著/)[0];
        var img = one(doc, ".book-info .cover img");
        cover = img ? String(img.attr("data-original") || img.attr("src") || "") : "";
        doc.select(".book-info p.intro").forEach(function (p) { state += (state ? " · " : "") + txt(p); });
        desc = txt(one(doc, ".book-desc .desc-cnt")) || txt(one(doc, ".book-desc"));
    } else {
        var h = one(doc, ".book-info h1.title");
        if (h) {
            name = String(h.html()).split('<')[0].trim();
            author = txt(one(h, "a"));
        } else {
            h = one(doc, "h3.title");
            name = h ? String(h.html()).split('<')[0].trim() : "";
            author = txt(one(doc, "h3.title a"));
        }
        var c = one(doc, ".book-hd .cover img") || one(doc, ".cover img");
        cover = c ? String(c.attr("src") || "") : "";
        state = txt(one(doc, ".update-state"));
        desc = txt(one(doc, ".book-desc"));
    }
    if (!name) return Response.error("CiWeiMao: không đọc được trang truyện (site đổi giao diện?): " + url);
    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: desc,
        detail: state + '<br>作者 : ' + author,
        ongoing: state.indexOf("连载") != -1,
        host: "https://www.ciweimao.com",
    });
}
