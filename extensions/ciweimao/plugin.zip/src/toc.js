function execute(url) {
    const bookId = url.match(/\d+/)[0];
    // vBook Android 1.2.4 không còn Http.post(...).params() (TypeError, đo 17/11/2026) → POST form bằng fetch (BBook v3).
    var res = fetch('https://www.ciweimao.com/chapter/get_chapter_list_in_chapter_detail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: 'book_id=' + bookId
    });
    if (!res.ok) return Response.error('CiWeiMao: không tải được mục lục (HTTP ' + res.status + ')');
    var doc = res.html();
    var el = doc.select("ul.book-chapter-list li a")
    const list = [];
    for (var i= 0; i < el.size(); i++) {
        var e = el.get(i);
        var lock = e.html().match('icon-lock');
        if(lock != null){
            var vip = '/vip';
        }else{var vip = ''}
        list.push({
            name: e.text(),
            url: e.attr("href")+vip,
            host: "https://www.ciweimao.com"
        })
    }
    return Response.success(list);
}