// Thư viện AES đặt tên aeslib.js, không đặt tên crypto.js: vBook 1.2.4 thấy tên đó thì nạp CryptoJS dựng sẵn của app thay vào (giải mã sai,
// đo 17/11/2026). Đừng viết lệnh nạp tên đó kể cả trong chú thích: vBook quét cả chú thích và chạy hỏng ("UniqueTag cannot be cast").
load("aeslib.js");

function cwMessage(data, fallback) {
    if (!data || typeof data !== "object") return fallback;
    return String(data.msg || data.message || data.tip || data.info || fallback);
}
function cwObject(data) {
    if (data && typeof data === "object" && data.data && typeof data.data === "object") {
        return data.data;
    }
    return data && typeof data === "object" ? data : {};
}
// Hai lớp AES-CBC: base64(IV 16 byte + bản mã), khoá chọn theo ký tự cuối rồi ký tự đầu của access key; lớp 1 ra chuỗi base64 của lớp 2.
// BBook v3 (17/11/2026): làm hết bằng WordArray của CryptoJS. Bản gốc đổi qua lại chuỗi nhị phân bằng base64.js — trên vBook Android
// 1.2.4 (Rhino) ra bản rõ hỏng ("Cannot decode base64"), còn Node/B-trans thì đúng; crypto.js gốc cũng mã hoá AES sai trên Rhino
// (cùng khoá/IV khác Node) → dùng bản CryptoJS của bqgooo-bbook (khớp Node), đặt tên aeslib.js.
function cwLayer(b64, key) {
    var raw = CryptoJS.enc.Base64.parse(b64);
    if (raw.sigBytes <= 16) throw new Error("Dữ liệu mã hóa bị thiếu IV");
    var iv = CryptoJS.lib.WordArray.create(raw.words.slice(0, 4), 16);
    var ct = CryptoJS.lib.WordArray.create(raw.words.slice(4), raw.sigBytes - 16);
    return CryptoJS.AES.decrypt(CryptoJS.lib.CipherParams.create({ ciphertext: ct }), CryptoJS.enc.Base64.parse(key), {
        iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7
    });
}
function cwDecrypt(content, keys, accessKey) {
    if (typeof content !== "string" || !content ||
        !keys || !Array.isArray(keys) || !keys.length ||
        typeof accessKey !== "string" || !accessKey) {
        throw new Error("Thiếu nội dung, danh sách khóa giải mã hoặc access key");
    }
    var k1 = keys[accessKey.charCodeAt(accessKey.length - 1) % keys.length];
    var k2 = keys[accessKey.charCodeAt(0) % keys.length];
    if (!k1 || !k2) throw new Error("Khóa chương không hợp lệ");
    var inner = cwLayer(content, k1).toString(CryptoJS.enc.Latin1).replace(/\s+/g, "");
    if (!inner) throw new Error("Không giải mã được dữ liệu chương");
    var value = cwLayer(inner, k2).toString(CryptoJS.enc.Utf8);
    if (!value) throw new Error("Không giải mã được dữ liệu chương");
    return value;
}
// Site chỉ giữ một access key mỗi phiên ci_session: hai chương xin key xen kẽ trong cùng phiên thì cả hai bị 400001 "此章节可能已删除"
// (đo 17/11/2026 bằng Node: phiên mới → được; A xin key, B xin key, rồi lấy A/B → cả hai 400001). Trình đọc vBook tải trước vài chương
// song song, dùng chung kho cookie → lỗi. Nên xếp hàng: khoá trong localStorage (các lượt chạy song song dùng chung), giữ tối đa 20 s;
// gặp 400001 thì xin key lại (tối đa 3 lần). Cùng lượt chạy giữ cookie phiên vừa cấp (Set-Cookie) để không lẫn phiên của lượt khác.
var LOCK_KEY = "cwm_chap_lock", LOCK_MS = 20000;
function cwSleep(ms) { try { sleep(ms); } catch (e) {} }
function cwLock(token) {
    for (var i = 0; i < 100; i++) {
        var cur = null;
        try { cur = localStorage.getItem(LOCK_KEY); } catch (e) { return; }
        var until = cur ? parseInt(String(cur).split("|")[0]) : 0;
        if (!cur || !(until > Date.now())) {
            try { localStorage.setItem(LOCK_KEY, (Date.now() + LOCK_MS) + "|" + token); } catch (e) { return; }
            cwSleep(60);
            var mine = "";
            try { mine = String(localStorage.getItem(LOCK_KEY) || ""); } catch (e) { return; }
            if (mine.split("|")[1] === token) return;
        }
        cwSleep(150 + Math.floor(Math.random() * 150));
    }
}
function cwUnlock(token) {
    try { if (String(localStorage.getItem(LOCK_KEY) || "").split("|")[1] === token) localStorage.removeItem(LOCK_KEY); } catch (e) {}
}

// Một lượt: xin access key rồi lấy chương. Trả {content, keys, accessKey} hoặc {error, retry}.
function cwFetchOnce(host, id, target) {
    // vBook Android 1.2.4 không mã hoá body dạng object thành form → tự mã hoá form (BBook v3).
    var headers = {"Referer": target, "x-requested-with": "XMLHttpRequest",
                   "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"};
    var sessionResponse = fetch(host + "/chapter/ajax_get_session_code", {
        method: "POST", headers: headers, body: "chapter_id=" + id
    });
    if (!sessionResponse.ok) {
        return { error: "CiWeiMao lấy khóa HTTP " + sessionResponse.status +
            ": website có thể yêu cầu CAPTCHA hoặc xác minh phiên truy cập." };
    }
    var sessionJSON = sessionResponse.json();
    var access = cwObject(sessionJSON);
    var accessKey = access.chapter_access_key || access.chapterAccessKey || sessionJSON.chapter_access_key;
    if (!accessKey || typeof accessKey !== "string") {
        return { error: "CiWeiMao: không nhận được chapter_access_key. " +
            cwMessage(sessionJSON, "Có thể website yêu cầu CAPTCHA/đăng nhập hoặc API đã thay đổi.") };
    }
    var chapterHeaders = {};
    for (var hk in headers) chapterHeaders[hk] = headers[hk];
    var setCookie = "";
    try { setCookie = String(sessionResponse.headers["set-cookie"] || sessionResponse.headers["Set-Cookie"] || ""); } catch (eC) {}
    var ci = /ci_session=[^;,\s]+/.exec(setCookie);
    if (ci) chapterHeaders["Cookie"] = ci[0];
    var chapterResponse = fetch(host + "/chapter/get_book_chapter_detail_info", {
        method: "POST", headers: chapterHeaders,
        body: "chapter_id=" + id + "&chapter_access_key=" + encodeURIComponent(accessKey)
    });
    if (!chapterResponse.ok) {
        return { error: "CiWeiMao lấy chương HTTP " + chapterResponse.status +
            ": website có thể yêu cầu CAPTCHA hoặc xác minh phiên truy cập." };
    }
    var result = chapterResponse.json();
    var chapter = cwObject(result);
    var content = chapter.chapter_content || chapter.content || result.chapter_content || result.content;
    var keys = chapter.encryt_keys || chapter.encrypt_keys || chapter.keys ||
               result.encryt_keys || result.encrypt_keys || result.keys;
    if (typeof keys === "string") {
        try { keys = JSON.parse(keys); } catch (ignored) { keys = null; }
    }
    if (!content || !Array.isArray(keys) || !keys.length) {
        return { retry: String(result && result.code) === "400001", error: "CiWeiMao: API không trả đủ chapter_content và encryt_keys. " +
            cwMessage(result, "Có thể bị CAPTCHA, hết phiên đăng nhập hoặc API đã thay đổi.") };
    }
    return { content: String(content), keys: keys, accessKey: String(accessKey) };
}

function execute(url) {
    var target = String(url || "");
    var match = target.match(/\/chapter\/(\d+)/);
    if (!match) return Response.error("CiWeiMao: URL chương không hợp lệ");
    if (/\/vip(?:[/?#]|$)/i.test(target)) {
        return Response.error("CiWeiMao: đây là chương VIP; hãy đăng nhập và mua chương hợp lệ trên website.");
    }
    var id = match[1], host = "https://www.ciweimao.com";
    var token = id + ":" + Math.random();
    try {
        var got = null;
        for (var attempt = 0; attempt < 3; attempt++) {
            cwLock(token);
            try { got = cwFetchOnce(host, id, target); } finally { cwUnlock(token); }
            if (!got.retry) break;
            cwSleep(300 + Math.floor(Math.random() * 700));
        }
        if (got.error) return Response.error(got.error);
        var plain = cwDecrypt(got.content, got.keys, got.accessKey);
        // Cuối mỗi đoạn có <span>chuỗi ngẫu nhiên</span> (site ẩn bằng CSS, chống chép) → bỏ cả nội dung span (BBook v3).
        var html = plain.replace(/<span[^>]*>[\s\S]*?<\/span>/gi, "")
                        .replace(/<[^>]*>/g, "")
                        .replace(/\r?\n/g, "<br>").trim();
        if (!html) return Response.error("CiWeiMao: chương trống sau khi giải mã.");
        return Response.success(html);
    } catch (e) {
        return Response.error("CiWeiMao tải chương: " +
            (e && e.message ? e.message : String(e)) +
            ". Nếu cần, hãy xác minh CAPTCHA trên website rồi thử lại.");
    }
}
