function execute() {
    return Response.success([
        { title: "完结作品", input: "https://ixdzs.tw/end/", script: "gen.js" },
        { title: "总榜", input: "https://ixdzs.tw/hot/", script: "gen.js" },
        { title: "月榜", input: "https://ixdzs.tw/hot/month/", script: "gen.js" },
        { title: "日榜", input: "https://ixdzs.tw/hot/day/", script: "gen.js" },
    ]);
}
