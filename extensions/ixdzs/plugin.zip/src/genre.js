function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "https://ixdzs.tw/sort/1/", script: "gen.js" },
        { title: "传统武侠", input: "https://ixdzs.tw/sort/10/", script: "gen.js" },
        { title: "修真仙侠", input: "https://ixdzs.tw/sort/2/", script: "gen.js" },
        { title: "都市青春", input: "https://ixdzs.tw/sort/3/", script: "gen.js" },
        { title: "军事历史", input: "https://ixdzs.tw/sort/4/", script: "gen.js" },
        { title: "网游竞技", input: "https://ixdzs.tw/sort/5/", script: "gen.js" },
        { title: "科幻灵异", input: "https://ixdzs.tw/sort/6/", script: "gen.js" },
        { title: "言情穿越", input: "https://ixdzs.tw/sort/7/", script: "gen.js" },
        { title: "耽美同人", input: "https://ixdzs.tw/sort/8/", script: "gen.js" },
        { title: "台言古言", input: "https://ixdzs.tw/sort/9/", script: "gen.js" },
        { title: "其他小说", input: "https://ixdzs.tw/sort/0/", script: "gen.js" },
    ]);
}
