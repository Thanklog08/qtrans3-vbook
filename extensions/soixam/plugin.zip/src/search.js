load('config.js');
load('categories.js');

// Tìm kiếm, kiêm bộ lọc thể loại (vBook không cho thêm ô lọc ở màn Thể loại; gõ tiếng Trung cũng khó):
// - Chữ Hán: tìm theo tên trên mọi nền tảng (source=全部) hoặc chỉ Fanqie (cài đặt); "tên@nền tảng" (诡秘之主@QQ阅读) tìm riêng.
// - Không có chữ Hán: trùng tên một thể loại Fanqie (tiếng Việt/Hán-Việt, không dấu cũng được: "tu tien", "tay phuong ky huyen")
//   thì ra danh sách thể loại đó; không trùng thì tìm như thường (tên Latin).
// - Thêm "@khac" ở cuối: tìm ở các nền tảng khác Fanqie (thể loại thì tìm theo tên Trung của thể loại).
function execute(key, page) {
    page = page ? parseInt(page, 10) : 1;
    key = String(key || "").trim();
    var other = false;
    var m = /@\s*(khac|khác|nguon khac|nguồn khác)\s*$/i.exec(key);
    if (m) { other = true; key = key.slice(0, m.index).trim(); }
    var source = other ? "全部" : CFG_SEARCH === "Chỉ Fanqie" ? "番茄" : "全部";
    var at = key.lastIndexOf("@");
    if (!other && at > 0) { source = key.slice(at + 1).trim() || source; key = key.slice(0, at).trim(); }
    if (!key) return Response.success([]);

    var res;
    var cat = /[一-鿿]/.test(key) ? null : findCategory(key);
    if (cat && !other) res = discoverBooks(categoryPath(cat.id, cat.gender), page);
    else res = searchBooks(cat ? cat.zh : key, source, page, other);
    if (!res) return Response.error(NO_SERVER);
    return Response.success(res.data, res.next);
}
