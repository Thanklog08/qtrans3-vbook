load('config.js');

// Nội dung chương: POST /content (thân như nguồn Legado 5.9.26: tone_id 4 cho truyện chữ, version 4.11.5.1), cookie qttoken
// nếu đã đăng nhập. Chữ trả về là văn bản, mỗi dòng một đoạn (có nền tảng chèn <img>): đổi thành <p>. Hết lượt khách hay
// lỗi thì trả lỗi kèm cách đăng nhập — không trả thành nội dung chương, để vBook không lưu lời báo lỗi thay cho chương.
function fetchContent(book, itemId) {
    return api("POST", "/content", { book_id: book.id }, {
        html: "", item_id: itemId, source: book.source, tab: book.tab, tone_id: "4",
        variable: JSON.stringify({ custom: "" }), version: "4.11.5.1", app: "阅读神评表情", god: false
    });
}

// Hết lượt khách máy chủ vẫn trả code 0, lời báo nằm ngay trong content: "您今日免登录访问次数已达上限(3次)！继续阅读请登录后
// 刷新页面。" (đo 28/9/2026).
function noticeOf(json) {
    var text = String((json && json.content) || "");
    if (text.length < 300 && /访问次数|已达上限|请登录|登录后|登陆后|开通会员|会员专享/.test(text)) return text.replace(/<[^>]+>/g, "").trim();
    if (!text.trim()) return String((json && json.msg) || "không có nội dung");
    return "";
}

function execute(url) {
    var itemId = param(url, "item_id");
    var book = bookOf(url);
    if (!itemId || !book) return null;
    var json = fetchContent(book, itemId);
    if (!json) return Response.error("Không kết nối được máy chủ Sói Xám (đã thử " + HOSTS.length + " máy).");
    var notice = noticeOf(json);
    // Đã có tài khoản trong cài đặt mà máy chủ vẫn đòi đăng nhập: token cũ hết hạn, đăng nhập lại một lần.
    if (notice && CFG_EMAIL && CFG_PASSWORD && !LOGIN_ERROR && loginWithPassword(true)) {
        json = fetchContent(book, itemId) || json;
        notice = noticeOf(json);
    }
    if (notice) {
        var quota = /访问次数|已达上限|免登录/.test(notice);
        var login = quota || /登录|登陆|游客|会员|vip|token/i.test(notice);
        var how = "Nhập email + mật khẩu Sói Xám trong cài đặt tiện ích (hoặc đăng nhập ở " + SERVER + "/login bằng trình duyệt của vBook), rồi tải lại chương.";
        var head = quota ? "Khách đã đọc hết 3 chương miễn phí hôm nay của Sói Xám." : login ? "Sói Xám yêu cầu đăng nhập." : "Sói Xám không trả được chương này.";
        if (LOGIN_ERROR) head += " Đăng nhập bằng tài khoản trong cài đặt không được: " + LOGIN_ERROR + ".";
        return Response.error(head + (login ? " " + how : "") + " (" + notice + ")");
    }
    var text = String(json.content || "");
    var title = String(json.title || "").trim();
    var out = [];
    text.replace(/\r/g, "").split("\n").forEach(function (line) {
        var t = line.trim();
        if (!t) return;
        // Dòng đầu trùng tên chương: vBook đã hiện tên chương.
        if (!out.length && title && t === title) return;
        out.push(/^<img\b[^>]*>$/i.test(t) ? t : "<p>" + escapeHtml(t) + "</p>");
    });
    return Response.success(out.join(""));
}
