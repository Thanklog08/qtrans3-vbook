load('config.js');
load('categories.js');

// Màn Thể loại: chỉ phần chính của Fanqie (nam 19, nữ 21 mục; kênh theo cài đặt), mỗi thể loại hai lối:
// - "Cà Chua · …": danh sách Fanqie của thể loại;
// - "Nguồn khác · …": tìm theo tên thể loại (tên Trung, tiện ích tự điền) trên các nền tảng khác Fanqie.
// Chủ đề, nhân vật, tình tiết (~300 mục) không liệt kê ở đây cho khỏi dài: gõ tên thể loại vào ô tìm kiếm (search.js).
function execute() {
    var genders = CFG_CHANNEL === "Nữ" ? [0] : CFG_CHANNEL === "Cả hai" ? [1, 0] : [1];
    var both = genders.length > 1;
    var main = [];
    genders.forEach(function (g) {
        CATEGORIES.forEach(function (c) {
            if (c[1] === g && c[2] === 0) main.push({ id: c[0], g: g, zh: c[3], vi: c[4] + (both ? (g === 1 ? " (nam)" : " (nữ)") : "") });
        });
    });
    var list = [];
    main.forEach(function (c) { list.push({ title: "Cà Chua · " + c.vi, input: categoryPath(c.id, c.g), script: "gen.js" }); });
    var seen = {};
    main.forEach(function (c) {
        if (seen[c.zh]) return;
        seen[c.zh] = true;
        list.push({ title: "Nguồn khác · " + c.vi.replace(/ \((nam|nữ)\)$/, ""), input: "search:" + c.zh, script: "gen.js" });
    });
    return Response.success(list);
}
