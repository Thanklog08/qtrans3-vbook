load('config.js');
load('categories.js');

// Màn Thể loại: đủ danh mục Fanqie của kênh đang chọn — 4 phần (Chính, Chủ đề, Nhân vật, Tình tiết; nam 172, nữ 199 mục), trong
// mỗi phần xếp theo ABC. Hai khối:
// - "Cà Chua · …": danh sách Fanqie của thể loại;
// - "Nguồn khác · …": tìm theo tên thể loại (tên Trung, tiện ích tự điền) trên các nền tảng khác Fanqie.
// vBook không cho thêm ô lọc ở màn này: lọc bằng ô tìm kiếm (search.js), gõ tên thể loại tiếng Việt không dấu.
var PARTS = ["Chính", "Chủ đề", "Nhân vật", "Tình tiết"];

/** Khoá xếp ABC: bỏ dấu, giữ cách chữ ("Cổ phong" trước "Công sở"). */
function sortKey(s) {
    var t = String(s || "").toLowerCase();
    VI_FOLD.forEach(function (r) { t = t.replace(r[0], r[1]); });
    return t;
}

function execute() {
    var genders = CFG_CHANNEL === "Nữ" ? [0] : CFG_CHANNEL === "Cả hai" ? [1, 0] : [1];
    var both = genders.length > 1;
    var rows = [];
    genders.forEach(function (g, gi) {
        CATEGORIES.forEach(function (c) {
            if (c[1] === g) rows.push({ id: c[0], g: g, gi: gi, part: c[2], zh: c[3], vi: c[4], key: sortKey(c[4]) });
        });
    });
    rows.sort(function (x, y) {
        return x.part - y.part || x.gi - y.gi || (x.key < y.key ? -1 : x.key > y.key ? 1 : 0);
    });
    var label = function (c) { return PARTS[c.part] + " · " + c.vi; };
    var list = [];
    rows.forEach(function (c) {
        var tag = both && !/\((nam|nữ)\)$/.test(c.vi) ? (c.g === 1 ? " (nam)" : " (nữ)") : "";
        list.push({ title: "Cà Chua · " + label(c) + tag, input: categoryPath(c.id, c.g), script: "gen.js" });
    });
    var seen = {};
    rows.forEach(function (c) {
        if (seen[c.zh]) return;
        seen[c.zh] = true;
        list.push({ title: "Nguồn khác · " + label(c), input: "search:" + c.zh, script: "gen.js" });
    });
    return Response.success(list);
}
