load('config.js');

// Danh sách của một mục menu. input:
// - "/get_discover?…" (không kèm máy chủ): bảng xếp hạng / thể loại Fanqie;
// - "search:<tên Trung>": thể loại ở "Nguồn khác" — tìm theo tên thể loại trên các nền tảng khác Fanqie.
function execute(input, page) {
    page = page ? parseInt(page, 10) : 1;
    input = String(input);
    var res = input.indexOf("search:") === 0
        ? searchBooks(input.slice(7), "全部", page, true)
        : discoverBooks(input, page);
    if (!res) return Response.error(NO_SERVER);
    return Response.success(res.data, res.next);
}
