load('config.js');

// "Cùng tác giả" ở trang truyện: input = "<tác giả>\t<nền tảng>". Tìm của Sói Xám khớp cả tên tác giả (三九音域 trên Fanqie: 3/11
// kết quả đúng tác giả, đo 28/9) → chỉ giữ truyện đúng tên tác giả, cùng nền tảng với truyện đang xem lên trước.
function execute(input) {
    var parts = String(input || "").split("\t");
    var author = (parts[0] || "").trim(), source = (parts[1] || "").trim();
    if (!author) return Response.success([]);
    var json = api("GET", "/search", { title: author, tab: TAB, source: "全部", page: 1, disabled_sources: "0" });
    if (!json) return Response.error(NO_SERVER);
    var rows = (json.data || []).filter(function (b) { return isBook(b) && String(b.author || "").trim() === author; });
    rows.sort(function (x, y) { return (x.source === source ? 0 : 1) - (y.source === source ? 0 : 1); });
    var seen = {}, data = [];
    rows.forEach(function (b) {
        var k = b.source + "|" + cleanName(b.book_name);
        if (seen[k]) return;
        seen[k] = true;
        data.push(listItem(b, true));
    });
    return Response.success(data);
}
