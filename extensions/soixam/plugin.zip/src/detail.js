load('config.js');
load('categories.js');

// Trang truyện: POST /detail. Thông tin ghi tiếng Việt (nền tảng, thể loại, trạng thái, số chữ, điểm, lượt đọc, nhân vật chính,
// chương mới nhất); tên truyện, tác giả, giới thiệu giữ nguyên để vBook dịch. Nhãn thể loại bấm được (thể loại Fanqie → danh sách
// Fanqie, còn lại → tìm theo tên ở nguồn khác); mục "Cùng tác giả" liệt kê truyện của đúng tác giả đó (suggests.js).
function execute(url) {
    var book = bookOf(url);
    if (!book) return null;
    var json = api("POST", "/detail", { book_id: book.id, source: book.source, tab: book.tab }, { html: "" });
    if (!json) return Response.error(NO_SERVER);
    var b = json.data;
    if (!b || !b.book_name) return Response.error("Sói Xám không có truyện này" + (json.msg ? ": " + json.msg : ""));
    var source = String(b.source || book.source);

    var lines = [];
    var add = function (label, value) { if (value) lines.push("<b>" + label + ":</b> " + escapeHtml(value)); };
    add("Nền tảng", platformName(source));
    add("Thể loại", String(b.category || b.tags || ""));
    add("Trạng thái", statusText(b.status));
    add("Độ dài", wordsText(b.word_number));
    var sc = scoreText(b.score); if (sc) add("Điểm", sc.replace("★", "") + "/10");
    var rc = countText(b.read_count), ra = countText(b.read_count_all);
    if (rc || ra) add("Lượt đọc", (rc ? rc + " người đang đọc" : "") + (rc && ra ? " · " : "") + (ra ? "tổng " + ra : ""));
    add("Nhân vật chính", String(b.role || "").replace(/,/g, ", "));
    var last = String(b.last_chapter_title || "");
    var at = dateText(b.last_chapter_update_time);
    if (last || at) add("Chương mới", last + (last && at ? " · " : "") + at);

    var genres = [], seen = {};
    String(b.category || b.tags || "").split(/[,，、\s]+/).forEach(function (name) {
        name = name.trim();
        if (!name || seen[name]) return;
        seen[name] = true;
        var c = null;
        CATEGORIES.forEach(function (x) { if (!c && x[3] === name) c = x; });
        if (c && source === "番茄") genres.push({ title: c[4], input: categoryPath(c[0], c[1]), script: "gen.js" });
        else genres.push({ title: c ? c[4] : name, input: "search:" + name, script: "gen.js" });
    });

    var author = String(b.author || "").trim();
    var suggests = author ? [{ title: "Cùng tác giả", input: author + "\t" + source, script: "suggests.js" }] : [];

    return Response.success({
        name: cleanName(b.book_name),
        cover: String(b.thumb_url || ""),
        author: author,
        description: escapeHtml(String(b.abstract || "")).replace(/\n/g, "<br>"),
        detail: lines.join("<br>"),
        ongoing: statusText(b.status) !== "Hoàn thành",
        genres: genres.length ? genres : undefined,
        suggests: suggests.length ? suggests : undefined,
        host: SERVER
    });
}
