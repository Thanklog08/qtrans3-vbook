// 11/2026: truyencom.com chuyển hướng sang wetruyen.com (cùng mã truyện, link trong trang đều là wetruyen.com); mạng VN chặn
// truyencom.com nhưng không chặn wetruyen.com, nên mặc định dùng wetruyen.com.
// truyencom.com (2026-09-25): khuôn truyenfull, HTML dựng sẵn. truyenhoan.com cùng mã nguồn và cùng nội dung nhưng mã
// truyện khác (lệch vài trăm), nên chỉ đổi tên miền cho phần duyệt mới; link truyện đã lưu giữ nguyên tên miền của nó.
var DOMAIN = (function () {
    var raw = "";
    try { if (typeof domain !== "undefined") raw = domain; } catch (e) {}
    raw = String(raw || "").replace(/"/g, "").trim().toLowerCase();
    return raw === "truyenhoan.com" || raw === "truyencom.com" ? raw : "wetruyen.com";
})();
var BASE_URL = "https://" + DOMAIN;
var MEMO_KEY = "tc_via_bt";

// Mạng điện thoại chặn DNS + SNI của site (VN, 11/2026: DNS trả ::1/127.0.0.1, rồi reset theo SNI). Tải thẳng lỗi kết nối thì nhờ
// B-trans tải hộ qua POST /v1/proxy (B-trans docs/11 §19: cần khoá thiết bị, chỉ host bị chặn). Host đã phải đi B-trans thì nhớ
// 24 giờ, gia hạn mỗi lần dùng (localStorage MEMO_KEY + host) để khỏi chờ lỗi tải thẳng mỗi lượt; host khác (ảnh, tên miền mới) vẫn tải thẳng. Cấu hình: bt_url_1, bt_key_5, bt_proxy_j (Tự động/Luôn/Tắt).
function cfgText(v) { return String(v === undefined || v === null ? "" : v).replace(/^"|"$/g, "").trim(); }

function btConf() {
    var url = "", key = "", mode = "";
    try { if (typeof bt_url_1 !== "undefined") url = cfgText(bt_url_1); } catch (e) {}
    try { if (typeof bt_key_5 !== "undefined") key = cfgText(bt_key_5); } catch (e) {}
    try { if (typeof bt_proxy_j !== "undefined") mode = cfgText(bt_proxy_j).toLowerCase(); } catch (e) {}
    url = (url || "https://b-trans.cedricspace.online").replace(/\/+$/, "").replace(/\/v1$/, "");
    mode = !key || mode.indexOf("tắt") === 0 ? "off" : mode.indexOf("luôn") === 0 ? "always" : "auto";
    return { url: url, key: key, mode: mode };
}

function hostKey(url) {
    var m = /^https?:\/\/([^\/?#]+)/i.exec(String(url || ""));
    return MEMO_KEY + ":" + (m ? m[1].toLowerCase() : "");
}

function viaMemo(url) {
    try { return parseInt(localStorage.getItem(hostKey(url)) || "0") > Date.now(); } catch (e) { return false; }
}

// Host của url đang đi B-trans (Luôn, hoặc Tự động vừa thấy tải thẳng lỗi).
function viaBtrans(url) {
    var c = btConf();
    return c.mode === "always" || (c.mode === "auto" && viaMemo(url));
}

// Lỗi kết nối: không có phản hồi, mã 0, hoặc 5xx không có link (runtime B-trans trả 504 + url rỗng khi lỗi mạng).
function netFail(r) { return !r || !r.status || (r.status >= 500 && !r.url); }

// Lỗi của chính proxy (khoá sai, host không được phép, quá lượt, không tải được) thì coi như không đi được B-trans.
function proxyBad(r) { return netFail(r) || [401, 403, 429, 502].indexOf(r.status) >= 0; }

function viaProxy(c, url, opts) {
    var req = { url: url, method: (opts && opts.method) || "GET", headers: (opts && opts.headers) || {} };
    if (opts && opts.body !== undefined && opts.body !== null) req.body = String(opts.body);
    try {
        return fetch(c.url + "/v1/proxy", {
            method: "POST",
            headers: { "Authorization": "Bearer " + c.key, "Content-Type": "application/json" },
            body: JSON.stringify(req)
        });
    } catch (e) { return null; }
}

// vBook Android 1.2.4 (đo 16/11/2026, MuMu): sau MỘT lỗi kết nối, mọi fetch/Http còn lại của cùng lượt chạy script trả 504 ngay
// (mọi host, chờ 3 s vẫn vậy); lượt sau bình thường. Nên tải thẳng lỗi thì nhớ host TRƯỚC khi gọi proxy: lượt này có thể hỏng,
// lượt sau đi proxy trước. Mỗi lần proxy được thì gia hạn, để khỏi vấp lại lỗi đó mỗi lần hết hạn; tải thẳng lại được thì quên.
var MEMO_MS = 24 * 60 * 60 * 1000;
function remember(url) { try { localStorage.setItem(hostKey(url), String(Date.now() + MEMO_MS)); } catch (e) {} }
function forget(url) { try { localStorage.removeItem(hostKey(url)); } catch (e) {} }

function get(url, opts) {
    var c = btConf(), r = null, memo = c.mode === "auto" && viaMemo(url);
    if (c.mode === "always" || memo) {
        r = viaProxy(c, url, opts);
        if (!proxyBad(r)) { if (memo) remember(url); return r; }
    }
    try { r = opts ? fetch(url, opts) : fetch(url); } catch (e) { r = null; }
    if (c.mode === "off") return r;
    if (!netFail(r)) { if (memo) forget(url); return r; }
    if (c.mode === "auto") remember(url);
    var p = viaProxy(c, url, opts);
    return proxyBad(p) ? r : p;
}

function fixUrl(url) {
    if (!url) return "";
    url = String(url).trim();
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return BASE_URL + url;
    if (url.indexOf("http") !== 0) return BASE_URL + "/" + url;
    return url.replace(/^http:/, "https:");
}

// Gốc một link: https://truyencom.com (lấy theo link, không theo cài đặt).
function hostOf(url) {
    var m = /^(https?:\/\/[^\/]+)/.exec(fixUrl(url));
    return m ? m[1] : BASE_URL;
}

// Danh sách: .list-truyen .row[itemtype] gồm ảnh lười (data-image), h3.truyen-title a, tác giả, số chương.
// Lưu ý runtime vBook: select(...).first() không trả null khi rỗng, phải kiểm size().
function parseList(doc) {
    var data = [], seen = {};
    doc.select(".list-truyen .row[itemtype]").forEach(function (row) {
        var a = row.select("h3.truyen-title a");
        if (a.size() === 0) return;
        a = a.first();
        var link = fixUrl(a.attr("href") + "");
        if (!link || seen[link]) return;
        seen[link] = true;
        var img = row.select("[data-image]");
        var author = (row.select(".author[itemprop=author]").text() + "").trim();
        var chapters = "";
        row.select(".author").forEach(function (s) {
            var t = (s.text() + "").trim();
            if (/chương/i.test(t)) chapters = t;
        });
        data.push({
            name: (a.text() + "").trim(),
            link: link,
            cover: img.size() > 0 ? fixUrl(img.first().attr("data-image") + "") : "",
            description: author ? author + (chapters ? " · " + chapters : "") : chapters,
            host: hostOf(link)
        });
    });
    return data;
}

// Trang N của danh sách: <gốc>/trang-N/ (trang 1 là chính gốc).
function withPage(url, page) {
    url = fixUrl(url).replace(/[?#].*$/, "").replace(/trang-\d+\/?$/, "");
    if (url.slice(-1) !== "/") url += "/";
    return parseInt(page) > 1 ? url + "trang-" + page + "/" : url;
}

// Trang cuối trong thanh phân trang (link "Last" hoặc số lớn nhất).
function lastPage(doc) {
    var last = 1;
    doc.select("ul.pagination a[href]").forEach(function (a) {
        var m = /trang-(\d+)/.exec(a.attr("href") + "");
        if (m && parseInt(m[1]) > last) last = parseInt(m[1]);
    });
    return last;
}

function nextPage(doc, page) {
    var cur = parseInt(page || "1");
    return cur < lastPage(doc) ? String(cur + 1) : null;
}
