// Tab trang chủ (18/11): danh sách lấy qua API app (gen.js) — "最新" cũ của trang web không còn; thay bằng các thể loại lớn.
function execute() {
    return Response.success([
        { title: "男生·玄幻", input: "0-202-a", script: "gen.js" },
        { title: "男生·都市", input: "0-203-a", script: "gen.js" },
        { title: "男生·历史", input: "0-56-a", script: "gen.js" },
        { title: "女生·现代言情", input: "1-1-a", script: "gen.js" },
        { title: "女生·古代言情", input: "1-2-a", script: "gen.js" },
        { title: "出版图书", input: "2-240-a", script: "gen.js" }
    ]);
}
