// Danh sách theo thể loại (18/11, B-trans S6): trang web www.qimao.com/shuku không vào được từ VN (bắt tay TLS treo) → danh sách rỗng
// ở cả web B-trans lẫn vBook. Đổi sang API app api-bc.wtzw.com/api/v4/category/get-list (cùng máy chủ với tìm/trang truyện/chương,
// ký md5(tham số xếp theo tên + muối)). input giữ dạng cũ "<kênh>-<thể loại>-<thể loại con>": kênh 0 nam, 1 nữ, 2 sách xuất bản; "a" = tất cả.
load('crypto.js');
function execute(input, page) {
    if (!page) page = '1';
    var p = String(input || '').split('-');
    var gender = p[0] === '1' ? '2' : (p[0] === '2' ? '3' : '1');
    var cat = p[2] && p[2] !== 'a' ? p[2] : (p[1] && p[1] !== 'a' ? p[1] : (gender === '2' ? '1' : (gender === '3' ? '240' : '202')));
    var q = { category_id: cat, gender: gender, is_complete: '', need_category: '0', need_filters: '0', page: String(page), sort: '1' };
    var keys = Object.keys(q).sort();
    var raw = '', qs = [];
    for (var i = 0; i < keys.length; i++) { raw += keys[i] + '=' + q[keys[i]]; qs.push(keys[i] + '=' + encodeURIComponent(q[keys[i]])); }
    qs.push('sign=' + CryptoJS.MD5(raw + 'd3dGiJc651gSQ8w1'));
    var response = fetch('https://api-bc.wtzw.com/api/v4/category/get-list?' + qs.join('&'), {
        method: 'GET',
        headers: {
            'platform': 'android',
            'app-version': '71900',
            'application-id': 'com.kmxs.reader',
            'sign': '' + CryptoJS.MD5('app-version=71900application-id=com.kmxs.readerplatform=androidd3dGiJc651gSQ8w1'),
            'user-agent': 'webviewversion/0'
        }
    });
    if (!response.ok) return Response.error('Qimao: HTTP ' + response.status);
    var j = response.json();
    var books = (j && j.data && j.data.books) || [];
    var data = [];
    for (var k = 0; k < books.length; k++) {
        var b = books[k];
        data.push({ name: b.title, link: String(b.id), cover: b.image_link, description: b.author, host: 'https://api-bc.wtzw.com' });
    }
    return Response.success(data, books.length ? String(parseInt(page) + 1) : '');
}
